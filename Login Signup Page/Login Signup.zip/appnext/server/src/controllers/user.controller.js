const db = require('../config/db');
const logger = require('../config/logger');

// Get all users
exports.getAllUsers = async (req, res, next) => {
  try {
    const [rows] = await db.query('SELECT * FROM users');
    res.status(200).json(rows);
    logger.info('Fetched all users successfully');
  } catch (error) {
    logger.error(`Error fetching users: ${error.message}`);
    next(error); // Pass the error to the global error handler
  }
};

// Create a user
exports.createUser = async (req, res, next) => {
  const { name, email } = req.body;

  if (!name || !email) {
    logger.warn('Validation failed: Name and email are required');
    return res.status(400).json({ message: 'Name and email are required' });
  }

  try {
    const [result] = await db.query('INSERT INTO users (name, email) VALUES (?, ?)', [name, email]);
    res.status(201).json({ id: result.insertId, name, email });
    logger.info(`User created successfully: ID=${result.insertId}, Name=${name}, Email=${email}`);
  } catch (error) {
    logger.error(`Error creating user: ${error.message}`);
    next(error); // Pass the error to the global error handler
  }
};

// Update a user
exports.updateUser = async (req, res, next) => {
  const { id } = req.params;
  const { name, email } = req.body;

  if (!name || !email) {
    logger.warn('Validation failed: Name and email are required');
    return res.status(400).json({ message: 'Name and email are required' });
  }

  try {
    const [result] = await db.query('UPDATE users SET name = ?, email = ? WHERE id = ?', [name, email, id]);

    if (result.affectedRows === 0) {
      logger.warn(`User not found: ID=${id}`);
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({ message: 'User updated successfully' });
    logger.info(`User updated successfully: ID=${id}, Name=${name}, Email=${email}`);
  } catch (error) {
    logger.error(`Error updating user: ${error.message}`);
    next(error); // Pass the error to the global error handler
  }
};

// Delete a user
exports.deleteUser = async (req, res, next) => {
  const { id } = req.params;

  try {
    const [result] = await db.query('DELETE FROM users WHERE id = ?', [id]);

    if (result.affectedRows === 0) {
      logger.warn(`User not found: ID=${id}`);
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({ message: 'User deleted successfully' });
    logger.info(`User deleted successfully: ID=${id}`);
  } catch (error) {
    logger.error(`Error deleting user: ${error.message}`);
    next(error); // Pass the error to the global error handler
  }
};
