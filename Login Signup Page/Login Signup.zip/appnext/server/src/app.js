const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const routes = require('./routes');
const logger = require('./config/logger');

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// HTTP request logging using Morgan and Winston
app.use(
  morgan('combined', {
    stream: {
      write: (message) => logger.info(message.trim()),
    },
  })
);

// Routes
app.use('/api', routes);

// 404 Error Handling for Undefined Routes
app.use((req, res, next) => {
  logger.warn(`404 - Route not found: ${req.originalUrl}`);
  res.status(404).json({ message: 'Route not found' });
});

// Centralized Error Handling
app.use((err, req, res, next) => {
  logger.error(`500 - Internal Server Error: ${err.message}`);
  logger.debug(err.stack); // Detailed stack trace for debugging (optional)
  res.status(500).json({ message: 'Internal server error' });
});

module.exports = app;
