(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages_index_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages_index_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_f1b02b._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_bad01e._.js",
    "static/chunks/node_modules_react-icons_lib_75a63d._.js",
    "static/chunks/node_modules_e4ccad._.js",
    "static/chunks/[root of the server]__149834._.js"
  ],
  "source": "entry"
});
