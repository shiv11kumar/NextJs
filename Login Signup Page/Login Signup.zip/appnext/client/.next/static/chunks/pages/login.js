__turbopack_load_page_chunks__("/login", [
  "static/chunks/node_modules_next_dist_f1b02b._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__b81514._.js",
  "static/chunks/pages_login_5771e1._.js",
  "static/chunks/pages_login_2cd71b._.js"
])
