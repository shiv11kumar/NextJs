__turbopack_load_page_chunks__("/signup", [
  "static/chunks/node_modules_next_dist_f1b02b._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__93acbf._.js",
  "static/chunks/pages_signup_5771e1._.js",
  "static/chunks/pages_signup_82455d._.js"
])
