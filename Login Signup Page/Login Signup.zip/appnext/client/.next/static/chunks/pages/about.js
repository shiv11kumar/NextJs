__turbopack_load_page_chunks__("/about", [
  "static/chunks/node_modules_next_dist_f1b02b._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__914f90._.js",
  "static/chunks/pages_about_5771e1._.js",
  "static/chunks/pages_about_ab0298._.js"
])
