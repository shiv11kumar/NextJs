__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_f1b02b._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__c31e4d._.js",
  "static/chunks/styles_globals_796361.css",
  "static/chunks/pages__app_5771e1._.js",
  "static/chunks/pages__app_e23e84._.js"
])
