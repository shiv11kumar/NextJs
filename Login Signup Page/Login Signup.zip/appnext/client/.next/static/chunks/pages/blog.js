__turbopack_load_page_chunks__("/blog", [
  "static/chunks/node_modules_next_dist_f1b02b._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__13f17c._.js",
  "static/chunks/pages_index_5771e1._.js",
  "static/chunks/pages_index_9e067c._.js"
])
