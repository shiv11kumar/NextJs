import {
  FaFacebook,
  FaLinkedin,
  FaGoogle,
  FaRegEnvelope,
  FaUser
} from "react-icons/fa";

import { MdLockOutline } from "react-icons/md";

import logo from "../public/images/merai.png";

import Image from "next/image";
import Login from './login.js';
import Link from 'next/link';

export default function signup() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-2 bg-blue-100">
      <main className="flex flex-col items-center justify-center w-full flex-1 px-20 text-center">
        <div className="bg-white rounded-2xl shadow-2xl flex w-2/3 max-w-4xl">
          <div className="w-2/5 bg-green-500 text-white rounded-tl-2xl rounded-bl-2xl py-36 px-12">
            <h2 className="text-3xl font-bold mb-2">Welcome Back!</h2>
            <div className="border-2 w-10 border-white inline-block mb-2"></div>

            <p className="mb-10">
              To keep connected with us please login with your personal info
            </p>

            <Link 
                href="/login" 
                className="border-2 border-white rounded-full px-12 py-2 inline-block font-semibold hover:bg-white hover:text-green-500"
              >
                Sign Up
              </Link>
          </div>

          <div className="w-3/5 p-5">
            <div className="text-left font-bold">
              <Image src={logo} alt="MerAI" width={20} height={50} />
              <span className="text-green-500">Mer</span>AI
            </div>
            <h1 className="text-left text-xs font-bold font-mono mb-2">
              Redesigning Future
            </h1>

            <div className="py-10">
              <h2 className="text-3xl font-bold text-green-500 mb-2">
                Create Account
              </h2>

              <div className="border-2 w-10 border-green-500 inline-block mb-2"></div>

              <div className="flex justify-center my-2">
                <a
                  href="#"
                  className="border-2 border-grey-200 rounded-full p-3 m-1"
                >
                  <FaFacebook className=" text-sm" />
                </a>

                <a
                  href="#"
                  className="border-2 border-grey-200 rounded-full p-3 m-1"
                >
                  <FaGoogle className=" text-sm" />
                </a>

                <a
                  href="#"
                  className="border-2 border-grey-200 rounded-full p-3 m-1"
                >
                  <FaLinkedin className=" text-sm" />
                </a>
              </div>

              <p className="text-gray-400 my-3">or use your email for registration</p>

              <div className="flex flex-col items-center">

              <div className="bg-gray-100 w-64 p-2 flex items-center mb-3">
                  <FaUser className="text-gray-400 m-1" />
                  <input
                    type="text"
                    placeholder="Name"
                    className="bg-gray-100 outline-none text-sm flex-1"
                  />
                </div>


                <div className="bg-gray-100 w-64 p-2 flex items-center mb-3">
                  <FaRegEnvelope className="text-gray-400 m-1" />
                  <input
                    type="email"
                    placeholder="Email"
                    className="bg-gray-100 outline-none text-sm flex-1"
                  />
                </div>

                <div className="bg-gray-100 w-64 p-2 flex items-center mb-3">
                  <MdLockOutline className="text-gray-400 m-1" />
                  <input
                    type="password"
                    placeholder="Password"
                    className="bg-gray-100 outline-none text-sm flex-1"
                  />
                </div>

                <a
                  href={Login}
                  className="border-2 border-green-500 text-green-500 rounded-full px-12 py-2 inline-block font-semibold hover:bg-green-500 hover:text-white"
                >
                  Sign Up
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
