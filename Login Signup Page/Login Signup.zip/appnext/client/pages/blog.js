import React from 'react'

const blog = props => {
  return (
    <div>blog</div>
  )
}


export default blog