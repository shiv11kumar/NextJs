import React, { Fragment, useState } from "react";
import {
  GlobalStyles,
  Head,
  Text,
  Span,
  Link,
  Input,
  Form,
  Container,
  FormContainer,
  SocialContainer,
  Button,
  OverlayContainer,
  OverlayPanel,
  Overlay,
} from "../styles/index.style";

import {
  FaFacebook,
  FaLinkedin,
  FaGoogle,
} from "react-icons/fa";

function App() {
  const [panelActive, setPanelActive] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [message, setMessage] = useState("");

  const onSignInEvent = () => {
    setPanelActive(false);
  };

  const onSignUpEvent = () => {
    setPanelActive(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e, type) => {
    e.preventDefault();

    try {
      const response = await fetch(`http://localhost:5000/${type}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage(data.message);
      } else {
        setMessage(data.message || "An error occurred");
      }
    } catch (error) {
      setMessage("Failed to connect to the server");
    }
  };

  return (
    <Fragment>
      <GlobalStyles />
      <Container
        id="container"
        className={`${panelActive ? "right-panel-active" : ""}`}
      >
        <FormContainer className="sign-up-container">
          <Form
            onSubmit={(e) => handleSubmit(e, "signup")}
          >
            <div className="text-green-500 font-bold text-2xl">
              Create Account
            </div>
            <SocialContainer>
              <Link href="#" className="social">
                <FaLinkedin className=" text-l" />
              </Link>
              <Link href="#" className="social">
                <FaGoogle className=" text-l" />
              </Link>
              <Link href="#" className="social">
                <FaFacebook className=" text-l" />
              </Link>
            </SocialContainer>
            <Span>or use your email for registration</Span>
            <Input
              type="text"
              placeholder="Name"
              name="name"
              value={formData.name}
              onChange={handleChange}
            />
            <Input
              type="text"
              placeholder="Email"
              name="email"
              value={formData.email}
              onChange={handleChange}
            />
            <Input
              type="text"
              placeholder="Password"
              name="password"
              value={formData.password}
              onChange={handleChange}
            />
            <Button>Sign Up</Button>
          </Form>
        </FormContainer>

        <FormContainer className="sign-in-container">
          <Form
            onSubmit={(e) => handleSubmit(e, "signin")}
          >
            <div className="text-green-500 font-bold text-2xl">Sign In</div>
            <SocialContainer>
              <Link href="#" className="social">
                <FaLinkedin className=" text-l" />
              </Link>
              <Link href="#" className="social">
                <FaGoogle className=" text-l" />
              </Link>
              <Link href="#" className="social">
                <FaFacebook className=" text-l" />
              </Link>
            </SocialContainer>
            <Span>or use your account</Span>
            <Input
              type="text"
              placeholder="Email"
              name="email"
              value={formData.email}
              onChange={handleChange}
            />
            <Input
              type="password"
              placeholder="Password"
              name="password"
              value={formData.password}
              onChange={handleChange}
            />
            <Link href="#">Forgot your password?</Link>
            <Button>Sign In</Button>
          </Form>
        </FormContainer>

        <OverlayContainer>
          <Overlay>
            <OverlayPanel className="overlay-left">
              <Head>Welcome Back!</Head>
              <Text>
                To keep connected with us please login with your personal info
              </Text>
              <Button className="ghost" id="signIn" onClick={onSignInEvent}>
                Sign In
              </Button>
            </OverlayPanel>
            <OverlayPanel className="overlay-right">
              <Head>Hello, Friend!</Head>
              <Text>
                Enter your personal details and start your journey with us
              </Text>
              <Button className="ghost" id="signUp" onClick={onSignUpEvent}>
                Sign Up
              </Button>
            </OverlayPanel>
          </Overlay>
        </OverlayContainer>
      </Container>
      {message && <div className="message">{message}</div>}
    </Fragment>
  );
}

export default App;
