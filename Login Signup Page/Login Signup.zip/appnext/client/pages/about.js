import React from 'react'

const about = props => {
  return (
    <div>about</div>
  )
}

export default about