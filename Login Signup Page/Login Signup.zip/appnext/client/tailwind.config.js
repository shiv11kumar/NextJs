/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',  // Includes all pages
    './components/**/*.{js,ts,jsx,tsx}',  // Includes all components
  ],
  theme: {
    extend: {
      colors: {
        primary: '#4CAF50',  // Custom color
        secondary: '#FFC107',
        accent: '#FF5722',
        background: '#f9fafb',
      },
      fontFamily: {
        sans: ['Helvetica', 'Arial', 'sans-serif'],
        heading: ['"Poppins"', 'sans-serif'],
      },
      spacing: {
        '128': '32rem',  // Custom spacing value
        '144': '36rem',
      },
    },
  },
  plugins: [],
}
